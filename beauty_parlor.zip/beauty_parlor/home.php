<?php
session_start();
include 'includes/header.php';
?>

<div class="content">
    <main>
        <h1>Welcome to Beauty Parlor</h1>
        <p>Your one-stop solution for all beauty services.</p>
    </main>
</div>

<?php include 'includes/footer.php'; ?>