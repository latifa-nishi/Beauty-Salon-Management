How to run the Beauty Palour Management System (BPMS) Project 
1. Download the zip file 
2. Extract the file and copy beauty_parlor folder 
3. Paste inside root directory (for xampp --> xampp/htdocs, for wamp --> wamp/www, for lamp --> var/www/html) 
4. Open PHPMyAdmin (http://localhost/phpmyadmin) 
5. Create a database with the name beauty_parlor
6. Import beauty_parlor.sql file (given inside the zip package in SQL file folder) 
7. Run the script --> http://localhost/ beauty_parlor (frontend)

LogIn Info

 *******Credential for ADMIN panel******* 
Email or Phone Number: latifa@admin.com/ 01234567890

*******Credential for RECEPTIONIST panel******* 
Email or Phone Number: farzana@bparlor.com/ 01799887766

*******Credential for STAFF panel******* 
Email or Phone Number: sultana@bparlor.com/ 01733445566

*******Credential for CUSTOMER panel******* 
Email or Phone Number: farzana@gmail.com/ 01711234567

Or Register as a new user.
