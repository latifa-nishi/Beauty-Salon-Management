<?php include 'includes/header.php'; ?>
<div class="content">
    <main>
        <h1>About Us</h1>
        <p>A fully functional beauty parlor management project, exclusively developed by enthusiastic students from the Department of Computer Science and Engineering (CSE), BUP, as part of the Database Management Systems (DBMS) Laboratory for the CSE 3110 course.</p>
    </main>
</div>
<?php include 'includes/footer.php'; ?>
