<footer>
        <p>&copy; 2025 Beauty Parlor. All rights reserved.</p>
    </footer>
    <script src="js/scripts.js"></script>
</body>
</html>